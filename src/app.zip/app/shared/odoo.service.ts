import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Injectable()
export class OdooService {

  constructor(private http: HttpClient) { }
  call_odoo_function(dbName, user, pass, modelName, functionName, data) {
    console.log(data);
    data = JSON.stringify(data);
    console.log(data);
    const nwData = {'paramlist': data};
    console.log(nwData);
    const odooUrl = "http://207.154.195.214:4000/call_method" + "/" + dbName + "/" +
     user + "/" + pass + "/" + modelName + "/" + functionName;
    return this.http.post(odooUrl, nwData);
  }
}
