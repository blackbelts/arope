import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.css']
})
export class InfoComponent implements OnInit {
  numOfTravelers: number[];
  types = [
    {value: 'spouse', viewValue: 'Spouse'},
    {value: 'kid', viewValue: 'Kid'}
  ];
  @Output() changeStatus = new EventEmitter();
  constructor() { }

  ngOnInit() {
    this.numOfTravelers = new Array(parseInt(localStorage.getItem('numOfTraveler')));
  }

  submitTravelerInfo(form: NgForm) {
    console.log(form);

    if(form.valid) {
      console.log('valid');
      this.changeStatus.emit(true);
    }
  }

}
