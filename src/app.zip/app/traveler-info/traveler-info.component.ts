import { Component, OnInit } from '@angular/core';
import { MatStepper } from '@angular/material/stepper';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-traveler-info',
  templateUrl: './traveler-info.component.html',
  styleUrls: ['./traveler-info.component.css']
})
export class TravelerInfoComponent implements OnInit {
  infoStatus = false;
  isCompleted = false;
  travelerInfoStatus = false;
  paymentStatus = false;
  secondFormGroup: FormGroup;

  constructor(
    private _formBuilder: FormBuilder
  ) { }

  ngOnInit() {

    if(this.infoStatus) {
      console.log('true');
    }

    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ''
    });

  }

  goForward(stepper: MatStepper, event){

    this.infoStatus = true;
    setTimeout(() => {
      if(this.infoStatus) stepper.next();
    }, 100);

  }
  goForwardToPayment(stepper: MatStepper, event){
    console.log('yes');
    this.travelerInfoStatus = true;
    setTimeout(() => {
      if(this.travelerInfoStatus) stepper.next();
    }, 100);

  }

  goForwardToDone(stepper: MatStepper, event){
    console.log('yes');
    this.paymentStatus = true;
    setTimeout(() => {
      if(this.paymentStatus) stepper.next();
    }, 100);

  }

}
