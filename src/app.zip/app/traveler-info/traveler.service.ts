import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { Subject } from 'rxjs';
import { UIService } from '../shared/ui.services';
import { OdooService } from '../shared/odoo.service';

@Injectable()
export class TravelerService {
  listBenfilts=[];
  loadListBenefits = new Subject<any[]>();
  constructor(private http: HttpClient, private uiService: UIService, private odoo:OdooService) {
    
  }

  fetchfetchBenefits() {
    this.onClear();
    this.uiService.loadingChangedStatus.next(false);
    const headers = new HttpHeaders({
      "Content-Type": "application/x-www-form-urlencoded"
    });
    const data = {paramlist: {filter: [],
      need: []}};
    this.odoo.call_odoo_function('travel_agency', 'demo', 'demo',
     'travel.benefits', 'search_read', data).subscribe(res => {
      for (const x in res) {
        const cover = res[x].cover;
        const limit = res[x].limit;
        this.listBenfilts.push({
          'cover': cover,
          'limit': limit
        });
      }

      this.loadListBenefits.next(this.listBenfilts);
   });
  }

  onClear() {
    this.loadListBenefits.next([]);
    this.listBenfilts = [];
  }

  // fetchBenefits(){
  //   this.http.post('')
  // }
}
