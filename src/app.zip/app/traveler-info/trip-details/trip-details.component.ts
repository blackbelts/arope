import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trip-details',
  templateUrl: './trip-details.component.html',
  styleUrls: ['./trip-details.component.css']
})
export class TripDetailsComponent implements OnInit {
  zone;
  type;
  age;
  when;
  till;
  numOfTraveler;
  constructor() { }

  ngOnInit() {
    this.zone = localStorage.getItem("zone");
    this.type = localStorage.getItem("type");
    this.age = localStorage.getItem("age");
    this.when = localStorage.getItem("when");
    this.till = localStorage.getItem("till");
    this.numOfTraveler = localStorage.getItem("numOfTraveler");


  }

}

