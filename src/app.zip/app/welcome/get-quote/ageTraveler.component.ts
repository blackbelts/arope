import { Component, Inject, OnInit } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { NgForm } from '@angular/forms';
import { WelcomeService } from '../welcome.service';
import { SiteSettingsService } from '../../shared/site_settings.service';
@Component({
  selector: "app-stop-training",
  template: `
    <form #fDialog="ngForm" (ngSubmit)="submitFormAges(fDialog)" >
      <div mat-dialog-content>

        

          
          <div *ngFor="let element of elements; let i = index">




          <span id="field-{{ i }}">


            <mat-grid-list cols="8" rowHeight="60px" gutterSize="10px">


            <mat-grid-tile  colspan="3">
           
              <span 
              style="color: #565656"
              fxFlex 
              fxFlexAlign="flex-start center" 
              >
              {{ i == 0 ? "Primary Traveler's Age:" : "Additional Traveler's Age:" }}
              </span>
              </mat-grid-tile>


              <mat-grid-tile  colspan="2">
              <div ngModelGroup="dates">


              <mat-form-field
                class="form-age-traveler"
                style="margin: auto 20px;
                width: 162px;"
                
              
              >

                <input
                  type="text"
                  matInput
                  [matDatepicker]="picker"
                  placeholder="Age Of Travel"
                  [ngModel]="dataList.dates['date-'+i]"
                  name="date-{{ i }}"
                  #ages="ngModel"
                  required

                />

                  <mat-datepicker-toggle
                    matSuffix
                    [for]="picker"
                  ></mat-datepicker-toggle>
                  <mat-datepicker  #picker [startAt]="dataList.dates['date-'+i]" startView="multi-year" ></mat-datepicker>
                </mat-form-field>
               </div>
              </mat-grid-tile>

              <mat-grid-tile colspan="2">
              <div ngModelGroup="types">
                <mat-form-field *ngIf="i!=0">
                  <mat-label>Type</mat-label>
                  <mat-select name="type-{{i}}" [ngModel]="dataList.types['type-'+i]" #type="ngModel">
                    <mat-option *ngFor="let type of types" [value]="type.value">
                      {{type.viewValue}}
                    </mat-option>
                  </mat-select>
                </mat-form-field>
              </div>
              </mat-grid-tile>

              <mat-grid-tile>
              <span 
              fxFlex 
              fxFlexAlign="flex-end" 
              style="margin: 25px 35px;    cursor: pointer;" 
              (click)="deleteElement(i)" 
              *ngIf="i != 0"
              required
              >
                <mat-icon>minimize</mat-icon>
              </span>

              </mat-grid-tile>

              </mat-grid-list>



          </span>



          </div>

          


      



      </div>
      <div mat-dialog-actions>
      <div
          style="cursor: pointer; color: #565656"
          onMouseOver="this.style.color='#073e89'"
          onMouseOut="this.style.color='#565656'"
          (click)="this.clickMe()"
          fxLayout fxLayoutAlign="flex-start"
        >
          <span
            class="mdi mdi-plus"
            style="    font-size: 20px;"
            icon-margin
          ></span>
          Add Additional Traveler
        </div>
        <div fxFlex fxLayout fxLayoutAlign="flex-end">
          <button
            mat-button
            type="submit"
            style="background-color: #073E89;
            color: #E4EAF2;"
            [disabled]="fDialog.invalid"

          >
            Done
          </button>
        </div>
      </div>
    </form>
  `
})
export class AgeTravelerComponent implements OnInit{
  elements = [];
  types = [
    {value: 'spouse', viewValue: 'Spouse'},
    {value: 'kid', viewValue: 'Kid'}
  ];
  dataList = {
    "dates": "",
    "types": ""
  }
  constructor(
    private dialogRef: MatDialogRef<AgeTravelerComponent>,
    @Inject(MAT_DIALOG_DATA) public passedData,
    private welcomeService: WelcomeService,
    private site_settings: SiteSettingsService
  ) {
  
    
  }

  ngOnInit() {
    let result = this.site_settings.isEmpty(this.passedData);
   
    if(result){
      console.log(this.passedData.datesList, 'newjson')
      let newJson = JSON.parse(this.passedData.datesList);  
      var genJson = JSON.parse(newJson);
    
      for (var dateItem in genJson.dates) {
        this.elements.push(this.elements.length);
      }
      
      this.dataList.dates = genJson.dates;
      this.dataList.types = genJson.types;

    } else {
      this.elements.push(this.elements.length);
    }
  }

  clickMe() {
    this.elements.push(this.elements.length);
  }

  submitFormAges(form: NgForm) {
    for (let age in form.value.dates) {
      form.value.dates[age] = this.site_settings.convertDate(form.value.dates[age]);
    }
    let listValue = {
      dates: form.value.dates,
      types: form.value.types
    };
    this.welcomeService.setListDates(listValue);
    this.dialogRef.close();
  }

  deleteElement(index: number) {
    const target_id = "field-"+index;
    const element_id = document.getElementById(target_id);
    element_id.parentNode.removeChild(element_id);
  }
}