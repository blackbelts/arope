import { Component, OnInit, Output, EventEmitter, OnDestroy, Input } from '@angular/core';
import { MatDialog } from "@angular/material";
import { AgeTravelerComponent } from "./ageTraveler.component";
import { Router } from "@angular/router";
import { NgForm } from '@angular/forms';
import { MatRadioChange } from '@angular/material';
import { WelcomeService } from '../welcome.service';
import { Subscription } from 'rxjs';
import { UIService } from '../../shared/ui.services';
import { OdooService } from '../../shared/odoo.service';
@Component({
  selector: "app-get-quote",
  templateUrl: "./get-quote.component.html",
  styleUrls: ["./get-quote.component.css"]
})
export class GetQuoteComponent implements OnInit, OnDestroy {
  countries = [
    { value: "zone 1", viewValue: "Europ" },
    { value: "zone 2", viewValue: "Worldwide excluding USA & CANADA" },
    { value: "zone 3", viewValue: "Worldwide" }
  ];
  isLoading=false;
  maxDate;
  breakpoint;
  isIndividual = true;
  agesString: string;
  ageLoadSubs: Subscription;
  loadingSubs: Subscription;
  familyDataString: string;
  @Output() change: EventEmitter<MatRadioChange>;
  constructor(
    public dialog: MatDialog,
    private router: Router,
    private welcomeService: WelcomeService,
    private uiService: UIService,
    private odoo:OdooService
  ) {}

  ngOnInit() {
    this.breakpoint = window.innerWidth <= 400 ? 1 : 2;
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate() - 0);

    this.loadingSubs = this.uiService.loadingChangedStatus.subscribe(res => {
      this.isLoading = res;
    });
  }

  onResize(event) {
    this.breakpoint = event.target.innerWidth <= 400 ? 1 : 2;
  }

  showPopup() {
    console.log(this.familyDataString);
    const dialogRef = this.dialog.open(AgeTravelerComponent, {
      data : {
        datesList: this.familyDataString
      },
      
     
      width: '800px',
      
    });
    dialogRef.afterClosed().subscribe(result => {
      let arr = [];
      this.familyDataString = JSON.stringify(this.welcomeService.getListDates());
      if(this.familyDataString) {
        let new_json = JSON.parse(this.welcomeService.getListDates());
        for(let i in new_json.dates) {
          arr.push(new_json.dates[i]);
        }

        this.agesString = arr.join(', ');
      }
    });
  }

  showField(event) {
    var valueField = event.value;
    if (valueField == "family") this.isIndividual = false;
    else this.isIndividual = true;
  }

  convertDate(dateAge) {
    let d = new Date(dateAge),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) {
        month = '0' + month;
    }
    if (day.length < 2) {
        day = '0' + day;
    }

    return [year, month, day].join('-');
  }

  submitForm(form: NgForm) {
    const when = this.convertDate(form.value.dateWhen);
    const till = this.convertDate(form.value.dateTill);
    const type = form.value.type;
    let ageArgs;

    //define function down
    if(type == 'individual'){
      ageArgs = form.value.indAge;
    }
    else{
      ageArgs = form.value.familyAges;
    }
    let age = this.typeAges(type, ageArgs);

    const data = {paramlist: {type: type, ages: age, whens: when, tills: till,
    zone: form.value.zone}};

    this.saveDataInLocalStorage(form);

    this.welcomeService.sendQuoteResult(data);
  }

  typeAges(type: string, ageArgs) {
    if(type == 'individual'){
      return [this.convertDate(ageArgs)];
   }
   else{
      return ageArgs.split(", ");
   }
  } 

  saveDataInLocalStorage(form) {
    var zone = "";
    this.countries.forEach(x => {
      if (x["value"] == form.value.zone) {
        zone = x["viewValue"];
      }
    });
    localStorage.setItem("zone", zone);
    let ageArgs;
    let type = form.value.type;
    if(type == 'individual'){
      ageArgs = form.value.indAge;
    }
    else{
      ageArgs = form.value.familyAges;
    }
    let valArg = this.typeAges(type, ageArgs);
    localStorage.setItem("type", type);

    const yearBirth = this.getAge(valArg[0]);
    localStorage.setItem("age", yearBirth.toString());

    localStorage.setItem("numOfTraveler", valArg.length);

    localStorage.setItem("when", form.value.dateWhen);
    localStorage.setItem("till", form.value.dateTill);
    console.log(yearBirth, localStorage.getItem("age"));
  }

  getAge(dateString) {
    var today = new Date();
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }

  ngOnDestroy() {
    this.loadingSubs.unsubscribe();

  }
}
