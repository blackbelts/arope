export interface WelcomeModel{
    
}