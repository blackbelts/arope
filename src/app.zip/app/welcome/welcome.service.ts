

import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Router } from '@angular/router';
import { map } from "rxjs/operators";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { UIService } from '../shared/ui.services';
import { OdooService } from '../shared/odoo.service';
@Injectable()
export class WelcomeService {
  resultData;
  priceLoad = new Subject<any>();
  constructor(private http: HttpClient, private router: Router,private uiService: UIService, private odoo: OdooService) {}

  setListDates(data) {
    this.resultData = data;
    console.log("resss", this.resultData);
  }

  getListDates() {
    return JSON.stringify(this.resultData);
  }

  sendQuoteResult(data) {

    this.uiService.loadingChangedStatus.next(true);
    
    this.odoo.call_odoo_function('travel_agency', 'demo', 'demo', 'policy.travel',
     'get_quote', data).subscribe(res => {
        localStorage.setItem('total_price', res.toString());
        this.priceLoad.next(11);
        this.uiService.loadingChangedStatus.next(false);
        this.router.navigate(["/traveler-info"]);
     });

  }
}

