export interface PaymentModel {
    cardNumber: number;
    expirationDate: Date;
    cvCode: number;
}